import { Pool } from 'pg';
let pool: Pool;

export async function initDB() {
  pool = new Pool({
    host: process.env.PG_HOST || '127.0.0.1',
    port: Number(process.env.PG_PORT || 5432),
    user: process.env.PG_USER || 'postgres',
    password: process.env.PG_PASSWORD || 'postgres',
    database: process.env.PG_DATABASE || 'order_exec'
  });

  await pool.query(`
    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      type TEXT,
      status TEXT,
      payload JSONB,
      created_at TIMESTAMP DEFAULT now(),
      updated_at TIMESTAMP DEFAULT now(),
      attempts INTEGER DEFAULT 0,
      fail_reason TEXT,
      tx_hash TEXT,
      executed_price NUMERIC
    );
  `);
}

export function getPool() {
  if (!pool) throw new Error('DB not initialized');
  return pool;
}
