import IORedis from 'ioredis';
let client: IORedis.Redis;

export async function initRedis() {
  client = new IORedis({
    host: process.env.REDIS_HOST || '127.0.0.1',
    port: Number(process.env.REDIS_PORT || 6379),
    password: process.env.REDIS_PASSWORD || undefined
  });
  await client.ping();
}

export function getRedis() {
  if (!client) throw new Error('Redis not initialized');
  return client;
}
