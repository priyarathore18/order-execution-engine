import { randomUUID } from 'crypto';
import { delay } from '../utils/helpers';

export type Dex = 'raydium' | 'meteora';

export async function getQuote(dex: Dex, baseAmount: number) {
  await delay(2000 + Math.floor(Math.random()*1000));
  const basePrice = 100;
  const variationPct = (Math.random()*3 + (dex === 'raydium' ? -2 : 0));
  const price = basePrice * (1 + variationPct/100);
  const liquidity = 1000000 * (Math.random()*0.5 + 0.5);
  return { dex, price, liquidity };
}

export async function routeToBestDex(baseAmount: number) {
  const [q1, q2] = await Promise.all([getQuote('raydium', baseAmount), getQuote('meteora', baseAmount)]);
  const chosen = q1.price <= q2.price ? q1 : q2;
  return { chosen, other: q1 === chosen ? q2 : q1, quotes: [q1, q2] };
}

export async function executeOnDex(chosen: {dex:string, price:number}, slippagePct:number){
  await delay(1000 + Math.floor(Math.random()*1000));
  const realizedPrice = chosen.price * (1 + (Math.random()-0.5)/100);
  const slippage = Math.abs((realizedPrice - chosen.price)/chosen.price) * 100;
  if(slippage > slippagePct){
    throw new Error(`Slippage ${slippage.toFixed(3)}% > allowed ${slippagePct}%`);
  }
  await delay(1000 + Math.floor(Math.random()*1000));
  const txHash = randomUUID().replace(/-/g, '');
  return { txHash, executedPrice: realizedPrice };
}
