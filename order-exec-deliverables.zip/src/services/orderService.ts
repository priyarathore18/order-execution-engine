import { v4 as uuidv4 } from 'uuid';
import { insertOrder } from '../models/orderModel';
import { getRedis } from './redisClient';
import { getQueue } from '../queue';

export async function createOrderHandler(payload:any, socket:any){
  const id = uuidv4();
  const redis = getRedis();
  await insertOrder({ id, type: 'market', status: 'pending', payload });
  await redis.hset(`active:${id}`, { status: 'pending' });

  const queue = getQueue();
  await queue.add('execute', { orderId: id, payload });

  (global as any)._wsSockets = (global as any)._wsSockets || {};
  (global as any)._wsSockets[id] = socket;

  return { id };
}
