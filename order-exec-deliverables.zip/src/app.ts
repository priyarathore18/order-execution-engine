import Fastify from 'fastify';
import websocket from '@fastify/websocket';
import ordersRoutes from './routes/orders';
import { initDB } from './services/db';
import { initRedis } from './services/redisClient';
import pino from 'pino';

const logger = pino();
const server = Fastify({ logger });

await initDB();
await initRedis();

await server.register(websocket);

server.register(ordersRoutes, { prefix: '/api/orders' });

const PORT = process.env.PORT || 3000;
server.listen({ port: Number(PORT), host: '0.0.0.0' }).then(() => {
  logger.info(`Server running on ${PORT}`);
});
