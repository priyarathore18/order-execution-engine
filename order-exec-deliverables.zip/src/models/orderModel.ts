import { getPool } from '../services/db';

export interface OrderRow {
  id: string;
  type: string;
  status: string;
  payload: any;
  attempts: number;
}

export async function insertOrder(row: Partial<OrderRow>) {
  const pool = getPool();
  await pool.query(
    `INSERT INTO orders (id, type, status, payload, attempts) VALUES ($1,$2,$3,$4,$5)`,
    [row.id, row.type || 'market', row.status || 'pending', row.payload || {}, row.attempts || 0]
  );
}

export async function updateOrderStatus(id: string, status: string, extras: any = {}) {
  const pool = getPool();
  const fields = ['status', 'updated_at'];
  const values = [status, new Date()];
  for (const k of Object.keys(extras)) {
    fields.push(k);
    values.push(extras[k]);
  }
  const setClause = fields.map((f, i) => `${f} = $${i+1}`).join(', ');
  await pool.query(`UPDATE orders SET ${setClause} WHERE id = $${fields.length+1}`, [...values, id]);
}
