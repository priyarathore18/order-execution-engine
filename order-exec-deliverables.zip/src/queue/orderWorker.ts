import { Job } from 'bullmq';
import { routeToBestDex, executeOnDex } from '../services/dexRouter';
import { updateOrderStatus } from '../models/orderModel';
import { getRedis } from '../services/redisClient';

export async function orderWorker(job: Job){
  const { orderId, payload } = job.data;
  const redis = getRedis();
  const slippagePct = Number(process.env.SLIPPAGE_PCT || 1);

  send(orderId, { status: 'pending' });

  try{
    send(orderId, { status: 'routing' });
    const routing = await routeToBestDex(payload.amount);

    send(orderId, { status: 'building' });
    send(orderId, { status: 'submitted' });

    const exec = await executeOnDex(routing.chosen, slippagePct);
    send(orderId, { status: 'confirmed', txHash: exec.txHash });

    await updateOrderStatus(orderId, 'confirmed', { tx_hash: exec.txHash, executed_price: exec.executedPrice });
  } catch(err:any) {
    send(orderId, { status: 'failed', error: err.message });
    await updateOrderStatus(orderId, 'failed', { fail_reason: err.message });
    throw err;
  }
}

function send(orderId:string, data:any){
  const sockets = (global as any)._wsSockets || {};
  const ws = sockets[orderId];
  if(ws && ws.socket){
    try{ ws.socket.send(JSON.stringify(data)); } catch(e){}
  }
}
