import { FastifyInstance } from 'fastify';
import { createOrderHandler } from '../services/orderService';

export default async function (fastify: FastifyInstance) {
  fastify.post('/execute', async (request, reply) => {
    const payload = request.body as any;
    const ws = (request as any).socket;

    const order = await createOrderHandler(payload, ws, reply.raw);
    return reply.code(201).send({ orderId: order.id });
  });
}
