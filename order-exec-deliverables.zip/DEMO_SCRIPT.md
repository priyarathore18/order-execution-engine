
DEMO SCRIPT (1-2 minutes)
1. Start docker-compose: `docker-compose up -d`
2. Install deps: `npm install`
3. Start dev server: `npm run dev`
4. POST 3-5 orders using curl or Postman:
   curl -X POST http://localhost:3000/api/orders/execute -H 'Content-Type: application/json' -d '{ "orderType":"market","tokenIn":"SOL","tokenOut":"USDC","amount":1 }'
5. Connect to WebSocket at ws://localhost:3000/api/orders/execute?orderId=<id>
6. Show terminal logs for routing decisions and queue processing.
