
describe('sanity', () => {
  test('package.json exists', () => {
    const fs = require('fs');
    expect(fs.existsSync('package.json')).toBeTruthy();
  });
  test('src folder exists', () => {
    const fs = require('fs');
    expect(fs.existsSync('src')).toBeTruthy();
  });
});
